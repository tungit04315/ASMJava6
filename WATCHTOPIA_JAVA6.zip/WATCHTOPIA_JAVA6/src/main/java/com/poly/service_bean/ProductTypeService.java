package com.poly.service_bean;

import java.util.List;

import com.poly.bean.ProductType;

public interface ProductTypeService {
	public List<ProductType> findAll();
}
