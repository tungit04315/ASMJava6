package com.poly.service_bean;

import java.util.List;

import com.poly.bean.ThongKe;

public interface ThongKeService {
	public List<ThongKe> getListTK();
	public Long getLuotMua();
}
