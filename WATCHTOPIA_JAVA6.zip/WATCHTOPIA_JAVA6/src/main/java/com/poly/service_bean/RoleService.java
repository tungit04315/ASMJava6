package com.poly.service_bean;

import com.poly.bean.Roles;

public interface RoleService {
	public Roles findbyId(String id);
}
