package com.poly.service_bean;

import com.poly.bean.UserRole;

public interface UserRoleService {
	public UserRole create(UserRole userRole);
}
