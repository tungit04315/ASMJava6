package com.poly.service_bean;

import java.util.List;

import com.poly.bean.ThongKe;

public interface StaticsService {

	public List<ThongKe> findAll();
}
