package com.poly.service_bean;

import java.util.List;

import com.poly.bean.Branch;

public interface BranchService {
	public List<Branch> findAll();
}
