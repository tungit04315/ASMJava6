package com.poly.map;

import java.util.HashMap;
import com.poly.bean.*;

public class UsersMAP extends HashMap<Integer, Users>{
	
}
