package com.poly.map;

import java.util.HashMap;
import com.poly.bean.Products;


public class ProductsMAP extends HashMap<Integer, ProductsMAP>{
}
