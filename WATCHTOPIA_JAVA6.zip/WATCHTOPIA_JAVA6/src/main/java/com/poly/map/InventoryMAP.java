package com.poly.map;

import java.util.HashMap;

import com.poly.bean.Inventory;

public class InventoryMAP extends HashMap<Integer, Inventory>{

}
