package com.poly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WatchtopiaJava6Application {

	public static void main(String[] args) {
		SpringApplication.run(WatchtopiaJava6Application.class, args);
	}

}
